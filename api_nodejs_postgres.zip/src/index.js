import app from "./app.js";

let PORT = 3001;
app.listen(PORT);
console.log("Servidor ejecutando en el puerto", PORT);
